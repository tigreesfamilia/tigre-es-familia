-- =====================================================================
-- Tigre es Familia · Cuentas y clasificación mundial de la Caravana Matadora
-- Proyecto Supabase: tigre-es-familia
--
-- Diseño de seguridad:
--  * Todas las tablas viven en el esquema "lb", que la API pública de Supabase
--    NO expone. Aunque alguien tenga la clave pública del juego, no puede leer
--    ni escribir tablas: solo puede llamar a las funciones lb_* de abajo.
--  * Las contraseñas se guardan con bcrypt (pgcrypto), nunca en texto plano.
--  * La sesión es un token aleatorio de 256 bits; en la base solo se guarda su
--    hash SHA-256.
--  * Los puntajes se validan en el servidor (ver lb_submit).
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

create schema if not exists lb;
revoke all on schema lb from public;
revoke all on schema lb from anon, authenticated;

-- ---------------------------------------------------------------------
-- Tablas
-- ---------------------------------------------------------------------
create table if not exists lb.players (
  id          uuid primary key default gen_random_uuid(),
  username    text not null check (username ~ '^[A-Za-z0-9_.-]{3,16}$'),
  pass_hash   text not null,
  hidden      boolean not null default false,   -- true = no aparece en la tabla (moderación)
  created_at  timestamptz not null default now(),
  last_seen   timestamptz not null default now()
);
create unique index if not exists lb_players_username_key on lb.players (lower(username));

create table if not exists lb.sessions (
  token_hash  text primary key,
  player_id   uuid not null references lb.players(id) on delete cascade,
  created_at  timestamptz not null default now(),
  expires_at  timestamptz not null
);
create index if not exists lb_sessions_player on lb.sessions (player_id, created_at desc);

create table if not exists lb.scores (
  player_id   uuid not null references lb.players(id) on delete cascade,
  mode        text not null check (mode in ('previa','clasico','final')),
  best        integer not null default 0,
  best_at     timestamptz,
  games       integer not null default 0,
  updated_at  timestamptz not null default now(),
  primary key (player_id, mode)
);
create index if not exists lb_scores_rank on lb.scores (mode, best desc, best_at asc);

create table if not exists lb.runs (
  id          uuid primary key default gen_random_uuid(),
  player_id   uuid not null references lb.players(id) on delete cascade,
  mode        text not null check (mode in ('previa','clasico','final')),
  started_at  timestamptz not null default now(),
  done        boolean not null default false
);
create index if not exists lb_runs_player on lb.runs (player_id, started_at desc);

create table if not exists lb.attempts (
  id    bigint generated always as identity primary key,
  kind  text not null,
  key   text not null,
  at    timestamptz not null default now()
);
create index if not exists lb_attempts_key on lb.attempts (kind, key, at desc);

alter table lb.players  enable row level security;
alter table lb.sessions enable row level security;
alter table lb.scores   enable row level security;
alter table lb.runs     enable row level security;
alter table lb.attempts enable row level security;
revoke all on all tables in schema lb from anon, authenticated;

-- ---------------------------------------------------------------------
-- Funciones internas (esquema lb, no accesibles desde la API)
-- ---------------------------------------------------------------------
create or replace function lb.err(p_code text, p_msg text)
returns jsonb language sql immutable set search_path = '' as $$
  select jsonb_build_object('ok', false, 'error', p_code, 'msg', p_msg)
$$;

create or replace function lb.client_ip()
returns text language plpgsql stable set search_path = '' as $$
declare h jsonb; ip text;
begin
  begin
    h := nullif(current_setting('request.headers', true), '')::jsonb;
  exception when others then
    h := null;
  end;
  ip := coalesce(h->>'cf-connecting-ip', h->>'x-real-ip',
                 split_part(coalesce(h->>'x-forwarded-for', ''), ',', 1));
  return coalesce(nullif(btrim(ip), ''), 'local');
end $$;

create or replace function lb.too_many(p_kind text, p_key text, p_max integer, p_secs integer)
returns boolean language sql stable set search_path = '' as $$
  select count(*) >= p_max from lb.attempts
   where kind = p_kind and key = p_key and at > now() - make_interval(secs => p_secs)
$$;

create or replace function lb.note(p_kind text, p_key text)
returns void language sql set search_path = '' as $$
  insert into lb.attempts (kind, key) values (p_kind, left(p_key, 80))
$$;

create or replace function lb.gc()
returns void language plpgsql set search_path = '' as $$
begin
  if random() < 0.03 then
    delete from lb.sessions where expires_at < now();
    delete from lb.attempts where at < now() - interval '1 day';
    delete from lb.runs     where started_at < now() - interval '1 day';
  end if;
end $$;

create or replace function lb.new_session(p_player uuid)
returns text language plpgsql set search_path = '' as $$
declare tok text := encode(extensions.gen_random_bytes(32), 'hex');
begin
  -- como máximo 10 sesiones por cuenta: se borran las más viejas
  delete from lb.sessions
   where player_id = p_player
     and token_hash in (select token_hash from lb.sessions where player_id = p_player
                         order by created_at desc offset 9);
  insert into lb.sessions (token_hash, player_id, expires_at)
  values (encode(extensions.digest(tok, 'sha256'), 'hex'), p_player, now() + interval '90 days');
  perform lb.gc();
  return tok;
end $$;

-- Devuelve el jugador dueño del token (o null) y renueva la sesión si hace falta.
create or replace function lb.auth(p_token text)
returns uuid language plpgsql set search_path = '' as $$
declare pid uuid; h text;
begin
  if p_token is null or length(p_token) <> 64 then return null; end if;
  h := encode(extensions.digest(p_token, 'sha256'), 'hex');
  update lb.sessions
     set expires_at = case when expires_at < now() + interval '60 days'
                           then now() + interval '90 days' else expires_at end
   where token_hash = h and expires_at > now()
  returning player_id into pid;
  if pid is not null then
    update lb.players set last_seen = now()
     where id = pid and last_seen < now() - interval '1 hour';
  end if;
  return pid;
end $$;

create or replace function lb.stats(p_player uuid)
returns jsonb language sql stable set search_path = '' as $$
  select jsonb_build_object(
    'modes', coalesce((select jsonb_object_agg(s.mode, jsonb_build_object('best', s.best, 'games', s.games))
                         from lb.scores s where s.player_id = p_player), '{}'::jsonb),
    'games', coalesce((select sum(s.games)::int from lb.scores s where s.player_id = p_player), 0)
  )
$$;

-- ---------------------------------------------------------------------
-- API pública (se llama desde el juego con la clave pública)
-- ---------------------------------------------------------------------

-- Crear cuenta. Devuelve la sesión ya iniciada.
create or replace function public.lb_register(p_username text, p_password text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  u   text := btrim(coalesce(p_username, ''));
  ip  text := lb.client_ip();
  pid uuid;
  tok text;
begin
  if u !~ '^[A-Za-z0-9_.-]{3,16}$' then
    return lb.err('usuario_invalido', 'El nombre debe tener de 3 a 16 caracteres: letras, números, _ . o -');
  end if;
  if lower(u) = any (array['admin','administrador','moderador','soporte','sistema','tigre_es_familia','tigreesfamilia']) then
    return lb.err('usuario_reservado', 'Ese nombre está reservado. Elegí otro.');
  end if;
  if p_password is null or char_length(p_password) < 4 or octet_length(p_password) > 72 then
    return lb.err('clave_invalida', 'La contraseña debe tener al menos 4 caracteres.');
  end if;
  if lb.too_many('register_ip', ip, 20, 3600) then
    return lb.err('demasiados_intentos', 'Se crearon demasiadas cuentas desde tu conexión. Probá más tarde.');
  end if;
  perform lb.note('register_ip', ip);
  begin
    insert into lb.players (username, pass_hash)
    values (u, extensions.crypt(p_password, extensions.gen_salt('bf', 10)))
    returning id into pid;
  exception when unique_violation then
    return lb.err('usuario_ocupado', 'Ese nombre ya está en uso. Elegí otro.');
  end;
  tok := lb.new_session(pid);
  return jsonb_build_object('ok', true, 'token', tok, 'user', u, 'stats', lb.stats(pid));
end $$;

-- Iniciar sesión (con límite de intentos fallidos por usuario y por conexión).
create or replace function public.lb_login(p_username text, p_password text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  u    text := btrim(coalesce(p_username, ''));
  pl   lb.players%rowtype;
  ip   text := lb.client_ip();
  good boolean := false;
  tok  text;
begin
  if u = '' or char_length(u) > 32 or p_password is null or octet_length(p_password) > 72 then
    return lb.err('credenciales', 'Usuario o contraseña incorrectos.');
  end if;
  if lb.too_many('login_ip', ip, 40, 900) or lb.too_many('login_user', lower(u), 8, 900) then
    return lb.err('demasiados_intentos', 'Demasiados intentos fallidos. Esperá unos minutos y probá de nuevo.');
  end if;
  select * into pl from lb.players where lower(username) = lower(u);
  if found then
    good := (pl.pass_hash = extensions.crypt(p_password, pl.pass_hash));
  else
    perform extensions.crypt(p_password, extensions.gen_salt('bf', 10));   -- mismo costo: no revela si el usuario existe
  end if;
  if not good then
    perform lb.note('login_ip', ip);
    perform lb.note('login_user', lower(u));
    return lb.err('credenciales', 'Usuario o contraseña incorrectos.');
  end if;
  delete from lb.attempts where kind = 'login_user' and key = left(lower(u), 80);
  tok := lb.new_session(pl.id);
  return jsonb_build_object('ok', true, 'token', tok, 'user', pl.username, 'stats', lb.stats(pl.id));
end $$;

-- Cerrar sesión (borra el token del servidor).
create or replace function public.lb_logout(p_token text)
returns jsonb language plpgsql security definer set search_path = '' as $$
begin
  delete from lb.sessions
   where token_hash = encode(extensions.digest(coalesce(p_token, ''), 'sha256'), 'hex');
  return jsonb_build_object('ok', true);
end $$;

-- Perfil y estadísticas de la cuenta (sirve para validar la sesión guardada y
-- para ver los récords desde cualquier dispositivo).
create or replace function public.lb_me(p_token text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare pid uuid := lb.auth(p_token); u text;
begin
  if pid is null then
    return lb.err('sesion', 'La sesión venció. Volvé a iniciar sesión.');
  end if;
  select username into u from lb.players where id = pid;
  return jsonb_build_object('ok', true, 'user', u, 'stats', lb.stats(pid));
end $$;

-- El juego avisa que empieza una partida. El servidor anota la hora: así puede
-- comprobar después que el puntaje es posible para el tiempo que pasó.
create or replace function public.lb_start(p_token text, p_mode text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare pid uuid := lb.auth(p_token); rid uuid;
begin
  if pid is null then
    return lb.err('sesion', 'La sesión venció. Volvé a iniciar sesión.');
  end if;
  if p_mode is null or p_mode not in ('previa','clasico','final') then
    return lb.err('modo', 'Modo inválido.');
  end if;
  if lb.too_many('run', pid::text, 400, 3600) then
    return lb.err('demasiados_intentos', 'Estás jugando demasiado rápido. Esperá un momento.');
  end if;
  perform lb.note('run', pid::text);
  insert into lb.runs (player_id, mode) values (pid, p_mode) returning id into rid;
  perform lb.gc();
  return jsonb_build_object('ok', true, 'run', rid);
end $$;

-- Registra el resultado de una partida.
--  * La partida debe existir, ser de esa cuenta y no haberse registrado antes.
--  * Cada hincha nuevo exige al menos 3 pasos (la bandera nunca aparece a menos
--    de 3 casilleros) y cada paso dura como mínimo el tiempo del modo; los
--    trofeos (+5) salen como mucho cada 9 segundos. Un puntaje imposible para
--    el tiempo transcurrido se rechaza.
--  * Si el puntaje supera el récord se actualiza; si no, se conserva el anterior.
create or replace function public.lb_submit(p_token text, p_run uuid, p_n integer)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  pid      uuid := lb.auth(p_token);
  r        lb.runs%rowtype;
  el_ms    numeric;
  tick     numeric;
  steps    integer;
  trmax    integer;
  nmax     integer;
  old_best integer;
  new_best integer;
  v_pos    integer;
  nuevo    boolean;
begin
  if pid is null then
    return lb.err('sesion', 'La sesión venció. Volvé a iniciar sesión.');
  end if;
  if p_run is null or p_n is null then
    return lb.err('partida_invalida', 'Partida inválida.');
  end if;
  select * into r from lb.runs where id = p_run and player_id = pid for update;
  if not found or r.done then
    return lb.err('partida_invalida', 'Esa partida no existe o ya se registró.');
  end if;
  update lb.runs set done = true where id = r.id;

  el_ms := extract(epoch from (now() - r.started_at)) * 1000;
  if el_ms > 3 * 3600 * 1000 then
    return lb.err('partida_vencida', 'La partida tardó demasiado en registrarse.');
  end if;
  tick  := case r.mode when 'previa' then 150 when 'clasico' then 85 else 62 end;
  steps := floor((el_ms + 4000) / tick * 1.1)::integer + 2;
  trmax := floor((el_ms + 4000) / 9000)::integer + 1;
  nmax  := least(480, 1 + steps / 3 + 4 * trmax);
  if p_n < 1 or p_n > nmax then
    return lb.err('puntaje_invalido', 'El servidor no aceptó ese puntaje.');
  end if;

  select best into old_best from lb.scores where player_id = pid and mode = r.mode;
  nuevo := p_n > coalesce(old_best, 0);

  insert into lb.scores as s (player_id, mode, best, best_at, games)
  values (pid, r.mode, p_n, now(), 1)
  on conflict (player_id, mode) do update set
    games      = s.games + 1,
    best       = greatest(s.best, excluded.best),
    best_at    = case when excluded.best > s.best then now() else s.best_at end,
    updated_at = now();

  select best into new_best from lb.scores where player_id = pid and mode = r.mode;

  with rk as (
    select row_number() over (order by sc.best desc, sc.best_at asc, lower(pl.username) asc) as pos, sc.player_id
      from lb.scores sc join lb.players pl on pl.id = sc.player_id
     where sc.mode = r.mode and sc.best > 0 and not pl.hidden
  )
  select rk.pos into v_pos from rk where rk.player_id = pid;

  return jsonb_build_object('ok', true, 'nuevo', nuevo, 'best', new_best,
                            'anterior', coalesce(old_best, 0), 'puesto', v_pos,
                            'stats', lb.stats(pid));
end $$;

-- Clasificación mundial por modo, paginada. Es pública: no hace falta sesión.
-- Si se manda un token válido, también devuelve el puesto de esa cuenta.
create or replace function public.lb_ranking(p_mode text default 'final', p_page integer default 1,
                                             p_size integer default 20, p_token text default null)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_mode  text    := coalesce(p_mode, 'final');
  v_size  integer := least(greatest(coalesce(p_size, 20), 1), 50);
  v_page  integer := greatest(coalesce(p_page, 1), 1);
  v_total integer;
  v_pages integer;
  v_rows  jsonb;
  v_me    jsonb := null;
  v_pid   uuid;
begin
  if v_mode not in ('previa','clasico','final') then
    return lb.err('modo', 'Modo inválido.');
  end if;
  select count(*) into v_total
    from lb.scores s join lb.players p on p.id = s.player_id
   where s.mode = v_mode and s.best > 0 and not p.hidden;
  v_pages := greatest(1, ceil(v_total::numeric / v_size)::integer);
  if v_page > v_pages then v_page := v_pages; end if;

  with r as (
    select row_number() over (order by s.best desc, s.best_at asc, lower(p.username) asc) as pos,
           s.player_id, p.username, s.best
      from lb.scores s join lb.players p on p.id = s.player_id
     where s.mode = v_mode and s.best > 0 and not p.hidden
  )
  select coalesce(jsonb_agg(jsonb_build_object(
           'pos', r.pos, 'user', r.username, 'best', r.best,
           'games', (select coalesce(sum(x.games), 0)::integer from lb.scores x where x.player_id = r.player_id)
         ) order by r.pos), '[]'::jsonb)
    into v_rows
    from r
   where r.pos > (v_page - 1) * v_size and r.pos <= v_page * v_size;

  v_pid := lb.auth(p_token);
  if v_pid is not null then
    with r as (
      select row_number() over (order by s.best desc, s.best_at asc, lower(p.username) asc) as pos,
             s.player_id, p.username, s.best
        from lb.scores s join lb.players p on p.id = s.player_id
       where s.mode = v_mode and s.best > 0 and not p.hidden
    )
    select jsonb_build_object('pos', r.pos, 'user', r.username, 'best', r.best,
             'games', (select coalesce(sum(x.games), 0)::integer from lb.scores x where x.player_id = r.player_id))
      into v_me from r where r.player_id = v_pid;
  end if;

  return jsonb_build_object('ok', true, 'mode', v_mode, 'page', v_page, 'pages', v_pages,
                            'size', v_size, 'total', v_total, 'rows', v_rows, 'me', v_me);
end $$;

-- ---------------------------------------------------------------------
-- Permisos: solo estas 7 funciones quedan abiertas a la clave pública.
-- ---------------------------------------------------------------------
revoke all on function public.lb_register(text, text)                  from public, anon, authenticated;
revoke all on function public.lb_login(text, text)                     from public, anon, authenticated;
revoke all on function public.lb_logout(text)                          from public, anon, authenticated;
revoke all on function public.lb_me(text)                              from public, anon, authenticated;
revoke all on function public.lb_start(text, text)                     from public, anon, authenticated;
revoke all on function public.lb_submit(text, uuid, integer)           from public, anon, authenticated;
revoke all on function public.lb_ranking(text, integer, integer, text) from public, anon, authenticated;

grant execute on function public.lb_register(text, text)                  to anon, authenticated;
grant execute on function public.lb_login(text, text)                     to anon, authenticated;
grant execute on function public.lb_logout(text)                          to anon, authenticated;
grant execute on function public.lb_me(text)                              to anon, authenticated;
grant execute on function public.lb_start(text, text)                     to anon, authenticated;
grant execute on function public.lb_submit(text, uuid, integer)           to anon, authenticated;
grant execute on function public.lb_ranking(text, integer, integer, text) to anon, authenticated;

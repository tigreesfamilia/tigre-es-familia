# Cuentas y clasificación mundial · Caravana Matadora

## Arquitectura
- **Sin servidor propio.** El juego (un solo `index.html`, en Netlify) habla directo con **Supabase** (Postgres).
- La base tiene un esquema privado `lb` (jugadores, sesiones, puntajes, partidas, intentos). La API pública **no lo expone**.
- El juego solo puede llamar a 7 funciones (`lb_register`, `lb_login`, `lb_logout`, `lb_me`, `lb_start`, `lb_submit`, `lb_ranking`), con la clave pública (`sb_publishable_…`), que por sí sola no da acceso a ninguna tabla.
- Contraseñas: bcrypt, mínimo 4 caracteres, sin otras reglas (letras, números o símbolos como quiera el jugador). Sesión: token aleatorio de 256 bits (en la base solo su hash), 90 días, queda guardada en el aparato → la sesión persiste al volver a abrir el juego.
- Récords y ranking viven en la base: se ven desde cualquier dispositivo y por todos los jugadores. El navegador solo guarda el token y un caché para mostrar.
- Sin sesión se puede jugar, pero no se envía nada al ranking (el récord de invitado queda solo en ese aparato).

## Validación de puntajes (anti-trampa)
- Al empezar una partida con sesión, el servidor anota la hora (`lb_start`). Al terminar (`lb_submit`) comprueba que el puntaje sea posible para el tiempo transcurrido (cada hincha exige ≥3 pasos, cada paso dura como mínimo lo que marca el modo, los trofeos salen cada ≥9 s). Una partida solo se puede registrar una vez y solo por su dueño.
- El récord solo sube; perder o reiniciar no lo baja.
- Límites: 8 intentos fallidos de login por usuario / 15 min, 40 por conexión, 20 altas por conexión / hora, 400 partidas / hora por cuenta.
- **Limitación honesta:** el servidor no simula el juego, así que alguien muy decidido podría enviar un puntaje *posible* pero no jugado. Se frena lo absurdo, no es a prueba de todo. Para ranking competitivo serio haría falta simular la partida en el servidor.
- Para ocultar a alguien del ranking: `update lb.players set hidden = true where username = '...';` (SQL Editor).

## Instalación (una vez)
1. Cuenta gratis en https://supabase.com y un proyecto nuevo.
2. **SQL Editor → New query**: pegar `schema.sql` entero → **Run** (se puede correr varias veces).
3. En el juego (`index.html`) ya están configuradas las dos constantes al inicio del bloque “CUENTAS Y CLASIFICACIÓN MUNDIAL”:
   - `LB_URL` = URL del proyecto (Settings → API)
   - `LB_KEY` = clave pública `sb_publishable_…` (Settings → API Keys). Si Supabase te diera solo la clave `anon` antigua, usala en su lugar.
   No hay variables de entorno: son datos públicos por diseño. **Nunca** pongas la `service_role` en el juego.
4. Publicar: subir `tigre-es-familia.zip` a Netlify como siempre. No hay nada más que iniciar.

## Costos
- Supabase plan Free: 500 MB de base, 50.000 usuarios activos/mes, sin costo. Un proyecto Free se **pausa tras 1 semana sin actividad** (se reactiva a mano desde el panel; no pierde datos).
- Si el juego crece mucho: plan Pro ≈ USD 25/mes. Netlify: lo que ya usás.

## Qué requiere intervención manual
- Correr `schema.sql` (hecho en el proyecto actual).
- Subir el zip a Netlify.
- Opcional: en Supabase → Authentication no hace falta tocar nada (no se usa Supabase Auth).

## Estado de las pruebas
- Servidor (Postgres real): registro, duplicados, validaciones, login correcto/incorrecto, bloqueo por intentos, sesión válida/falsa, logout, récord que sube y que no baja, partida repetida/ajena, puntaje imposible rechazado, dos cuentas en el mismo ranking, paginación, permisos de la clave pública.
- Interfaz: en un navegador simulado con servidor falso. **No se probó contra Supabase desde un navegador real** (el entorno de desarrollo no llega a internet): la primera prueba real es en Netlify.
